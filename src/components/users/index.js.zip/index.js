import React from 'react'
import User from './user'

export default class Users extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            users: [
                {
                    firstname: 'Amare',
                    lastname: 'lastname',
                    email: 'amare@gmail.com',
                    isAdmin: false
                },
                {
                    firstname: 'Aminata',
                    lastname: 'lastname',
                    email: 'Aminata@gmail.com',
                    isAdmin: false
                },
                {
                    firstname: 'Pierre',
                    lastname: 'lastname',
                    email: 'Pierre@gmail.com',
                    isAdmin: false
                },
                {
                    firstname: 'Ansy',
                    lastname: 'lastname',
                    email: 'ansy@gmail.com',
                    isAdmin: true
                },
            ]
        }
    }

    render() {

        let UsersList = this.state.users.map((user, index) => {
            return (
                <User
                    key={'user-' + index}
                    number={index}
                    firstname={user.firstname}
                    lastname={user.lastname}
                    email={user.email}
                />
            )
        })

        // console.log('Our initial array of users :', this.state.users);
        // console.log('Array of React components :', UsersList);


        // let firstHalfOfUsers = this.state.users.slice(0, this.state.users.length / 2);
        // console.log('first half of users :', firstHalfOfUsers)

        // let secondHalfOfUsers = this.state.users.slice(this.state.users.length / 2, this.state.users.length);
        // console.log('second half of users :', secondHalfOfUsers)

        // firstHalfOfUsers = firstHalfOfUsers.map((user, index) => {
        //     return (
        //         <User
        //             key={'user-' + index}
        //             number={index}
        //             firstname={user.firstname}
        //             lastname={user.lastname}
        //             email={user.email}
        //         />
        //     )
        // })

        // secondHalfOfUsers = secondHalfOfUsers.map((user, index) => {
        //     return (
        //         <User
        //             key={'user-' + index}
        //             number={index}
        //             firstname={user.firstname}
        //             lastname={user.lastname}
        //             email={user.email}
        //         />
        //     )
        // })

        // console.log('first half of users :', firstHalfOfUsers)
        // console.log('second half of users :', secondHalfOfUsers)

        let firstHalfOfUsers = UsersList.slice(0, UsersList.length / 2);
        let secondHalfOfUsers = UsersList.slice(UsersList.length / 2, UsersList.length);

        // console.log(firstHalfOfUsers);
        // console.log(secondHalfOfUsers);

        

        let adminList = this.state.users.find(user => {
            return user.isAdmin
        })

        // console.log(adminList);

        return (
            <section>
                <h3>Liste des utilisateurs :</h3>
                <p>First half</p>
                {firstHalfOfUsers}
                <p>Second half</p>
                {secondHalfOfUsers}
            </section>
        )
    }
}